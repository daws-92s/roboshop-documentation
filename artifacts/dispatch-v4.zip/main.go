// dispatch reads paid orders from the RabbitMQ "orders" queue and ships them.
// It only makes outbound connections, so it has no HTTP port.
package main

import (
	"context"
	"encoding/json"
	"fmt"
	"log/slog"
	"math/rand/v2"
	"net/url"
	"os"
	"os/signal"
	"strconv"
	"syscall"
	"time"

	amqp "github.com/rabbitmq/amqp091-go"
)

// the same names payment.py declares, so either side can start first
const (
	exchange   = "robot-shop"
	queue      = "orders"
	routingKey = "orders"
)

type order struct {
	OrderID  string `json:"orderid"`
	User     string `json:"user"`
	PlacedAt string `json:"placedAt"`
	Cart     struct {
		Total float64 `json:"total"`
		Items []struct {
			SKU string `json:"sku"`
			Qty int    `json:"qty"`
		} `json:"items"`
	} `json:"cart"`
}

var log = slog.New(slog.NewJSONHandler(os.Stdout, nil)).With("service", "dispatch")

func env(key, fallback string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return fallback
}

func main() {
	amqpURL := (&url.URL{
		Scheme: "amqp",
		User:   url.UserPassword(env("AMQP_USER", "guest"), env("AMQP_PASS", "guest")),
		Host:   env("AMQP_HOST", "rabbitmq") + ":" + env("AMQP_PORT", "5672"),
		Path:   "/",
	}).String()
	// simulated packing time per order
	delayMs, err := strconv.Atoi(env("DISPATCH_DELAY_MS", "500"))
	if err != nil {
		delayMs = 500
	}

	// systemctl stop sends SIGTERM: finish the current order, then exit
	ctx, stop := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
	defer stop()

	for {
		err := consume(ctx, amqpURL, time.Duration(delayMs)*time.Millisecond)
		if ctx.Err() != nil {
			log.Info("shutting down")
			return
		}
		log.Error("lost connection to RabbitMQ, retrying in 5s", "host", env("AMQP_HOST", "rabbitmq"), "error", err.Error())
		select {
		case <-time.After(5 * time.Second):
		case <-ctx.Done():
			log.Info("shutting down")
			return
		}
	}
}

// consume connects, declares the queue and handles messages until the
// connection drops (returns the error) or ctx is cancelled (returns nil).
func consume(ctx context.Context, amqpURL string, delay time.Duration) error {
	conn, err := amqp.Dial(amqpURL)
	if err != nil {
		return err
	}
	defer conn.Close()

	ch, err := conn.Channel()
	if err != nil {
		return err
	}
	if err := ch.ExchangeDeclare(exchange, "direct", true, false, false, false, nil); err != nil {
		return err
	}
	if _, err := ch.QueueDeclare(queue, true, false, false, false, nil); err != nil {
		return err
	}
	if err := ch.QueueBind(queue, routingKey, exchange, false, nil); err != nil {
		return err
	}
	// one order at a time; RabbitMQ keeps the rest in the queue
	if err := ch.Qos(1, 0, false); err != nil {
		return err
	}
	msgs, err := ch.Consume(queue, "dispatch", false, false, false, false, nil)
	if err != nil {
		return err
	}
	log.Info("connected to RabbitMQ, waiting for orders", "queue", queue)

	closed := conn.NotifyClose(make(chan *amqp.Error, 1))
	for {
		select {
		case <-ctx.Done():
			return nil
		case amqpErr := <-closed:
			if amqpErr == nil {
				return fmt.Errorf("connection closed")
			}
			return amqpErr
		case msg, ok := <-msgs:
			if !ok {
				return fmt.Errorf("delivery channel closed")
			}
			handle(msg, delay)
		}
	}
}

func handle(msg amqp.Delivery, delay time.Duration) {
	// payment puts the request id in the message header, so this log line
	// can be matched with the frontend, payment, cart and user logs
	requestID, _ := msg.Headers["X-Request-Id"].(string)
	l := log.With("requestId", requestID)

	var o order
	if err := json.Unmarshal(msg.Body, &o); err != nil || o.OrderID == "" {
		// a broken message will never succeed, so drop it instead of retrying forever
		l.Error("rejecting invalid order message", "body", string(msg.Body))
		msg.Nack(false, false)
		return
	}

	items := 0
	for _, it := range o.Cart.Items {
		// the shipping cost is a line in the cart too, it is not a product
		if it.SKU != "SHIP" {
			items += it.Qty
		}
	}
	l.Info("order received", "orderid", o.OrderID, "user", o.User, "items", items, "total", o.Cart.Total)

	start := time.Now()
	time.Sleep(delay)
	msg.Ack(false)

	l.Info("order dispatched",
		"orderid", o.OrderID,
		"trackingId", fmt.Sprintf("RS%010d", rand.IntN(1e10)),
		"durationMs", time.Since(start).Milliseconds())
}
