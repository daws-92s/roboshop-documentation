module dispatch

go 1.25

require github.com/rabbitmq/amqp091-go v1.15.0
